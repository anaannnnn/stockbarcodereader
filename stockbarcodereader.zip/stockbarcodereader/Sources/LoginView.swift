import SwiftUI

struct LoginView: View {
    var body: some View {
        Text("Login Screen")
    }
}
