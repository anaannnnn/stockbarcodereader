import SwiftUI
import AVFoundation

struct BarcodeScannerView: View {
    var body: some View {
        Text("Scanner will show here")
    }
}
