import Foundation

class AuthViewModel: ObservableObject {
    @Published var isAuthenticated = false
}
